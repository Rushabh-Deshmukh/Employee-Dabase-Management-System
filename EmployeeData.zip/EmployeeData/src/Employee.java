import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Employee {

	private JFrame frame;
	private JTextField jtxtEmployeeID;
	private JTable table;
	private JTextField jtxtFirstname;
	private JTextField jtxtNINumber;
	private JTextField jtxtSurname;
	private JTextField jtxtGender;
	private JTextField jtxtDOB;
	private JTextField jtxtAge;
	private JTextField jtxtSalary;
	
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	DefaultTableModel model= new DefaultTableModel();
	
	/**
	 * Launch the application.
	 */
	public void updateTable() 
	{
		conn=EmployeeData.ConnectionDB();
		
		if (conn !=null)
		{
			String sql= "Select EmpID,NINumber,Firstname,Surname,Gender,DOB,Age,Salary";
		
		try
		{
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			Object[] columnData=new Object[8];
			
			while(rs.next()) {
				columnData [0]= rs.getString("EmpID");
				columnData [1]= rs.getString("NINumber");
				columnData [2]= rs.getString("Firstname");
				columnData [3]= rs.getString("Surname");
				columnData [4]= rs.getString("Gender");
				columnData [5]= rs.getString("DOB");
				columnData [6]= rs.getString("Age");
				columnData [7]= rs.getString("Salary");
				model.addRow(columnData);
			}
		}
		catch(Exception e)
		{
		JOptionPane.showMessageDialog(null, e);	
		}
	  }
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Employee window = new Employee();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Employee() {
		initialize();
		conn=EmployeeData.ConnectionDB();
		Object col[]= {"EmpID","NINumber","Firstname","Surname","Gender","DOB","Age","Salary"};
		model.setColumnIdentifiers(col);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1450, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Employee ID");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel.setBounds(115, 131, 121, 16);
		frame.getContentPane().add(lblNewLabel);
		
		jtxtEmployeeID = new JTextField();
		jtxtEmployeeID.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtEmployeeID.setBounds(306, 128, 308, 28);
		frame.getContentPane().add(jtxtEmployeeID);
		jtxtEmployeeID.setColumns(10);
		
		JButton btnNewButton = new JButton("Print");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MessageFormat header=new MessageFormat("Printing in Progress");
				MessageFormat footer=new MessageFormat("page{0,number,integer}");
				
				try 
				{
					table.print();
				}
				catch(java.awt.print.PrinterException ev) {
					System.err.format("NoPrinter found",ev.getMessage());
				}
			}
		});
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 18));
		btnNewButton.setBounds(306, 588, 164, 61);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(668, 131, 758, 378);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"EmpID", "NINumber ", "FirstName", "Surname", "Gender ", "DOB", "Age", "Salary"
			}
		));
		table.setFont(new Font("Dialog", Font.BOLD, 18));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_1 = new JLabel("NI Number");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1.setBounds(115, 184, 121, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("First Name");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(115, 233, 121, 16);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Surname");
		lblNewLabel_1_2.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(115, 272, 121, 28);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Gender");
		lblNewLabel_1_3.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(115, 327, 121, 29);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("DOB");
		lblNewLabel_1_4.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(115, 384, 121, 29);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Age");
		lblNewLabel_1_5.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(115, 429, 121, 38);
		frame.getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Salary");
		lblNewLabel_1_6.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(115, 477, 121, 32);
		frame.getContentPane().add(lblNewLabel_1_6);
		
		jtxtFirstname = new JTextField();
		jtxtFirstname.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtFirstname.setColumns(10);
		jtxtFirstname.setBounds(306, 224, 308, 28);
		frame.getContentPane().add(jtxtFirstname);
		
		jtxtNINumber = new JTextField();
		jtxtNINumber.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtNINumber.setColumns(10);
		jtxtNINumber.setBounds(306, 177, 308, 29);
		frame.getContentPane().add(jtxtNINumber);
		
		jtxtSurname = new JTextField();
		jtxtSurname.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtSurname.setColumns(10);
		jtxtSurname.setBounds(306, 272, 308, 28);
		frame.getContentPane().add(jtxtSurname);
		
		jtxtGender = new JTextField();
		jtxtGender.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtGender.setColumns(10);
		jtxtGender.setBounds(306, 324, 308, 29);
		frame.getContentPane().add(jtxtGender);
		
		jtxtDOB = new JTextField();
		jtxtDOB.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtDOB.setColumns(10);
		jtxtDOB.setBounds(306, 381, 308, 28);
		frame.getContentPane().add(jtxtDOB);
		
		jtxtAge = new JTextField();
		jtxtAge.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtAge.setColumns(10);
		jtxtAge.setBounds(306, 432, 308, 28);
		frame.getContentPane().add(jtxtAge);
		
		jtxtSalary = new JTextField();
		jtxtSalary.setFont(new Font("Dialog", Font.BOLD, 18));
		jtxtSalary.setColumns(10);
		jtxtSalary.setBounds(306, 479, 308, 30);
		frame.getContentPane().add(jtxtSalary);
		
		JButton btnAddNew = new JButton("Add New");
		btnAddNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String sql="INSERT INTO employee(EMpID,NINumber,FirstName,Surname,Gender,DOB,Age,Salary)VALUES(?,?,?,?,?,?,?,?)";
				try
				{
					pst=conn.prepareStatement(sql);
					pst.setString(1, jtxtEmployeeID.getText());
					pst.setString(2, jtxtNINumber.getText());
					pst.setString(3, jtxtFirstname.getText());
					pst.setString(4, jtxtSurname.getText());
					pst.setString(5, jtxtGender.getText());
					pst.setString(6, jtxtDOB.getText());
					pst.setString(7, jtxtAge.getText());
					pst.setString(8, jtxtSalary.getText());
					pst.execute();
					rs.close();
					pst.close();
				}
				catch(Exception ev)
				{
					JOptionPane.showMessageDialog(null, "System Update Completed");	
				}
				
				DefaultTableModel model=(DefaultTableModel) table.getModel();
				model.addRow(new Object[] {
						 jtxtEmployeeID.getText(),
						 jtxtNINumber.getText(),
						 jtxtFirstname.getText(),
						 jtxtSurname.getText(),
						 jtxtGender.getText(),
						 jtxtDOB.getText(),
						 jtxtAge.getText(),
						 jtxtSalary.getText(),
						
				});
				if(table.getSelectedRow()== -1)
				{
					if(table.getRowCount()==0)
					{
						JOptionPane.showMessageDialog(null, "Membership Update confirm","Employee Database System",
								JOptionPane.OK_OPTION);
					}
				}
				
				
			}
		});
		btnAddNew.setFont(new Font("Dialog", Font.BOLD, 18));
		btnAddNew.setBounds(99, 588, 164, 61);
		frame.getContentPane().add(btnAddNew);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtxtEmployeeID.setText(null);
				jtxtNINumber.setText(null);
				jtxtFirstname.setText(null);
				jtxtSurname.setText(null);
				jtxtGender.setText(null);
				jtxtDOB.setText(null);
				jtxtAge.setText(null);
				jtxtSalary.setText(null);
			}
		});
		btnReset.setFont(new Font("Dialog", Font.BOLD, 18));
		btnReset.setBounds(502, 588, 164, 61);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame=new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Employee Database System",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setFont(new Font("Dialog", Font.BOLD, 18));
		btnExit.setBounds(692, 588, 164, 64);
		frame.getContentPane().add(btnExit);
		
		JLabel lblNewLabel_2 = new JLabel("EMPLOYEE DATABASE MANAGEMENT SYSTEM");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(306, 25, 710, 53);
		frame.getContentPane().add(lblNewLabel_2);
	}
}
